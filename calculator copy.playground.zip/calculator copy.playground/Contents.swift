import UIKit

var numA: Float = 1
var result: Float = 0

func sum(numB: Float){
    result = numA + numB
}
sum(numB: 3)
print(result)

func divide(numB: Float){
    result = numA / numB
}

divide(numB: 0.1)
print(result)

func minus(numB: Float){
    result = numA - numB
}
minus(numB: 1)
print(result)

func times(numB: Float){
    result = numA * numB
}
times(numB: 2)
print(result)
