import UIKit

func getRecieptSum(reciepts: Array<Double>) -> Double{
    var sum = 0.0
    for elemnt in reciepts{
        sum += elemnt
    }
    
    
    return sum
    
}
let sumOfReciepts = getRecieptSum(reciepts: [1, 40, 22.7, 60])

print("\(sumOfReciepts) $")

